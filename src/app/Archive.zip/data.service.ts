import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class DataService {
	constructor(private http: HttpClient) { }

	getUsers() {
		return this.http.get('https://jsonplaceholder.typicode.com/users')
	}

	getPosts() {
		return this.http.get('https://jsonplaceholder.typicode.com/posts')
	}

	getIncidents(filter = {}) {
		return this.http.post('http://192.168.1.10:8000/api/v1/getincidents/', filter)
	}
}
